/* Pandox settings. Edit the values between the quotes, save, and upload this file next to index.html and admin.html.
   Leave a value empty to hide it in the customer app. Nothing here is secret: the anon key is meant to be public;
   it only ever does what the database's row-level security and functions allow (see backend/schema.sql). */
window.PX_CONFIG = {
  legal: {
    legalName: "",      /* registered business name, for example "Pandox Enterprise" */
    regNo: "",          /* Registrar General registration number */
    address: "Akim Oda, Eastern Region, Ghana",
    email: "",          /* support email */
    dpcRegNo: "",       /* Data Protection Commission registration number */
    tin: "",            /* GRA tax identification number */
    supportHours: ""    /* for example "Monday to Saturday, 8am to 6pm" */
  },
  policy: {
    returnDays: 7,
    refundDays: 7,
    cancelPaymentHours: 48,
    freeDelivery: "GH\u20B55,000"
  },
  /* Fill these in after you follow backend/ADMIN_SETUP.md. Both the customer app and admin.html use them. */
  api: {
    url: "",         /* https://YOUR-PROJECT-REF.supabase.co/functions/v1 */
    projectUrl: "",   /* https://YOUR-PROJECT-REF.supabase.co */
    anonKey: ""       /* Project Settings, API, anon public key */
  },
  payLink: ""   /* Paystack or Flutterwave payment page link for card payments */
};
