/* Pandox service worker: saves the customer app so it opens without internet.
   admin.html is never cached and never served from cache. The dashboard always needs a
   live, authenticated connection, so a stale or offline copy of it must never be shown. */
const V = "pandox-1.0.1-202610080955";
const CORE = ["index.html", "legal.html", "manifest.json", "px-config.js", "icon-180.png", "icon-192.png", "icon-512.png"];

self.addEventListener("install", (e) => {
  e.waitUntil((async () => {
    const c = await caches.open(V);
    await c.add(new Request("index.html", { cache: "reload" }));
    await Promise.allSettled(CORE.slice(1).map((u) => c.add(new Request(u, { cache: "reload" }))));
    await self.skipWaiting();
  })());
});

self.addEventListener("activate", (e) => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== V && k.startsWith("pandox-")) await caches.delete(k);
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", (e) => {
  const r = e.request;
  if (r.method !== "GET") return;
  const u = new URL(r.url);
  if (u.origin !== location.origin) return;
  if (u.pathname.endsWith("admin.html")) return; // let the browser fetch the dashboard directly, every time

  if (r.mode === "navigate") {
    const key = u.pathname.endsWith("legal.html") ? "legal.html" : "index.html";
    e.respondWith((async () => {
      const c = await caches.open(V);
      const hit = await c.match(key);
      const net = fetch(r).then((res) => { if (res.ok) c.put(key, res.clone()); return res; }).catch(() => null);
      if (hit) { e.waitUntil(net); return hit; }
      return (await net) || new Response("You are offline and the app is not saved yet. Connect once to save it.", { status: 503, headers: { "Content-Type": "text/plain" } });
    })());
    return;
  }

  e.respondWith((async () => {
    const c = await caches.open(V);
    const hit = await c.match(r);
    if (hit) return hit;
    try { const res = await fetch(r); if (res.ok) c.put(r, res.clone()); return res; }
    catch (err) { return new Response("", { status: 504 }); }
  })());
});
