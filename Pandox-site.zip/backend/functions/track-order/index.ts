// Supabase Edge Function: track-order
// GET ?ref=PX123ABC&phone=0241234567 returns the order status. Both values must match.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": Deno.env.get("ALLOWED_ORIGIN") ?? "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
  auth: { persistSession: false },
});

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "GET") return json({ error: "method not allowed" }, 405);
  const u = new URL(req.url);
  const ref = u.searchParams.get("ref") ?? "";
  const phone = u.searchParams.get("phone") ?? "";
  if (!/^PX[A-Z0-9]{4,10}$/.test(ref) || phone.length < 9 || phone.length > 20) return json({ error: "invalid" }, 422);
  const { data, error } = await db.rpc("track_order", { p_ref: ref, p_phone: phone });
  if (error) { console.error(error); return json({ error: "server error" }, 500); }
  if (data?.status === "not_found") return json({ error: "not found" }, 404);
  return json(data);
});
