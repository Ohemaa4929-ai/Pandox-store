// Supabase Edge Function: paystack-webhook
// Deploy with --no-verify-jwt. Paystack signs every call; we check the signature before we trust it.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
  auth: { persistSession: false },
});

function safeEqual(a: string, b: string) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("method not allowed", { status: 405 });
  const secret = Deno.env.get("PAYSTACK_SECRET_KEY");
  if (!secret) return new Response("not configured", { status: 500 });

  const raw = await req.text();
  const sig = req.headers.get("x-paystack-signature") ?? "";
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-512" }, false, ["sign"]);
  const mac = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(raw));
  const hex = [...new Uint8Array(mac)].map((b) => b.toString(16).padStart(2, "0")).join("");
  if (!safeEqual(hex, sig)) return new Response("bad signature", { status: 401 });

  let ev: any;
  try { ev = JSON.parse(raw); } catch { return new Response("bad json", { status: 400 }); }

  if (ev.event === "charge.success" && ev.data?.status === "success") {
    const orderRef = ev.data?.metadata?.order_ref;
    if (typeof orderRef === "string" && /^PX[A-Z0-9]{4,10}$/.test(orderRef)) {
      const { error } = await db.rpc("mark_paid", {
        p_ref: orderRef,
        p_provider_ref: String(ev.data.reference),
        p_amount: Number(ev.data.amount) / 100, // Paystack sends pesewas
        p_raw: ev.data,
      });
      if (error) { console.error(error); return new Response("server error", { status: 500 }); }
    }
  }
  return new Response("ok", { status: 200 });
});
