// Supabase Edge Function: create-order
// Validates the request, then calls the create_order SQL function, which prices the order on the server.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": Deno.env.get("ALLOWED_ORIGIN") ?? "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, idempotency-key",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
  auth: { persistSession: false },
});

const str = (v: unknown, min: number, max: number) =>
  typeof v === "string" && v.trim().length >= min && v.trim().length <= max;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "method not allowed" }, 405);

  let b: any;
  try { b = await req.json(); } catch { return json({ error: "bad json" }, 400); }

  const valid =
    /^PX[A-Z0-9]{4,10}$/.test(b?.ref ?? "") &&
    str(b?.name, 2, 80) && str(b?.phone, 9, 20) &&
    ["mtn", "other", "card"].includes(b?.payMethod) &&
    Array.isArray(b?.items) && b.items.length >= 1 && b.items.length <= 30 &&
    b.items.every((i: any) => typeof i?.id === "string" && i.id.length <= 20 && Number.isInteger(i?.qty) && i.qty >= 1 && i.qty <= 99) &&
    str(b?.address?.line, 3, 200) && str(b?.address?.city, 2, 80);
  if (!valid) return json({ error: "invalid order" }, 422);
  if (req.headers.get("idempotency-key") !== b.ref) return json({ error: "idempotency key must equal ref" }, 400);

  const payload = {
    ref: b.ref,
    name: b.name,
    phone: b.phone,
    address: { line: b.address.line, city: b.address.city, region: String(b.address.region ?? "").slice(0, 60) },
    instructions: String(b.instructions ?? "").slice(0, 500),
    payMethod: b.payMethod,
    promo: String(b.promo ?? "").slice(0, 20),
    items: b.items.map((i: any) => ({ id: i.id, qty: i.qty })),
  };

  let res = await db.rpc("create_order", { p: payload });
  if (res.error?.code === "23505") res = await db.rpc("create_order", { p: payload }); // same ref arrived twice at once
  if (res.error) {
    const code = res.error.code;
    if (code === "54000") return json({ error: "too many orders, try later" }, 429);
    if (code === "22023") return json({ error: res.error.message }, 422);
    console.error("create_order failed", res.error);
    return json({ error: "server error" }, 500);
  }
  return json(res.data, 201);
});
