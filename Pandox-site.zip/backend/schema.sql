-- =====================================================================
-- PANDOX BACKEND v2 (Supabase / PostgreSQL)
-- Public store + private owner dashboard share these tables.
-- Run this whole file once in the Supabase SQL editor, then seed_products.sql.
-- It replaces the earlier v1 schema (never deployed).
-- Status: written with care but NOT yet run against a live database.
-- =====================================================================
create extension if not exists pgcrypto;

create sequence if not exists public.receipt_seq;
create sequence if not exists public.order_seq;
create sequence if not exists public.product_seq;

-- ---------------------------------------------------------------- staff
create table if not exists public.staff_members (
  user_id uuid primary key references auth.users (id) on delete cascade,
  email text,
  display_name text,
  role text not null check (role in ('owner', 'staff')),
  permissions text[] not null default '{}',
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create unique index if not exists one_owner on public.staff_members (role) where role = 'owner';

create table if not exists public.settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.categories (
  name text primary key,
  section text not null default 'market' check (section in ('market', 'decor')),
  sort int not null default 0,
  is_active boolean not null default true
);

create table if not exists public.products (
  id text primary key,
  name text not null,
  category text not null,
  section text not null default 'market' check (section in ('market', 'decor')),
  sub_category text,
  description text,
  image_url text,
  min_price numeric(12,2) not null default 0 check (min_price >= 0),
  max_price numeric(12,2) check (max_price is null or max_price >= min_price),
  cost_price numeric(12,2) not null default 0 check (cost_price >= 0),
  on_sale boolean not null default false,
  stock int not null default 0 check (stock >= 0),
  track_stock boolean not null default false,
  low_stock_level int not null default 3 check (low_stock_level >= 0),
  published boolean not null default true,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text not null,
  phone_norm text not null unique,
  address text,
  city text,
  region text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  ref text not null unique check (ref ~ '^P[A-Z][A-Z0-9]{4,10}$'),
  source text not null default 'online' check (source in ('online', 'walk_in', 'whatsapp')),
  customer_id uuid references public.customers (id),
  customer_name text not null check (char_length(customer_name) between 2 and 80),
  phone text not null default '',
  phone_norm text not null default '',
  address jsonb not null default '{}'::jsonb,
  instructions text check (instructions is null or char_length(instructions) <= 500),
  pay_method text check (pay_method is null or pay_method in ('mtn', 'other', 'card', 'cash', 'mixed')),
  promo text,
  subtotal numeric(12,2) not null default 0,
  discount numeric(12,2) not null default 0,
  delivery_fee numeric(12,2) not null default 0,
  tax_amount numeric(12,2) not null default 0,
  total numeric(12,2) not null default 0,
  amount_paid numeric(12,2) not null default 0,
  amount_refunded numeric(12,2) not null default 0,
  payment_status text not null default 'unpaid' check (payment_status in ('unpaid', 'partial', 'paid', 'refunded')),
  status text not null default 'pending'
    check (status in ('pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'cancelled', 'returned', 'paid', 'refunded')),
  cancelled_reason text,
  notes text,
  created_by uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists orders_phone_idx on public.orders (phone_norm, created_at desc);
create index if not exists orders_created_idx on public.orders (created_at desc);

create table if not exists public.order_items (
  id bigint generated always as identity primary key,
  order_id uuid not null references public.orders (id),
  product_id text not null references public.products (id),
  name text not null,
  qty int not null check (qty between 1 and 999),
  unit_price numeric(12,2) not null,
  unit_cost numeric(12,2) not null default 0,
  line_total numeric(12,2) not null,
  returned_qty int not null default 0 check (returned_qty >= 0)
);
create index if not exists order_items_order_idx on public.order_items (order_id);

create table if not exists public.payments (
  id bigint generated always as identity primary key,
  order_id uuid not null references public.orders (id),
  order_ref text not null,
  kind text not null check (kind in ('manual', 'provider')),
  verified boolean not null default false,
  method text not null check (method in ('cash', 'mtn_momo', 'telecel_cash', 'airteltigo_money', 'bank_transfer', 'card_manual', 'card_online', 'other')),
  amount numeric(12,2) not null check (amount > 0),
  currency text not null default 'GHS',
  reference text,
  note text,
  provider text,
  provider_ref text unique,
  raw jsonb,
  recorded_by uuid,
  received_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  check ((kind = 'provider' and verified) or (kind = 'manual' and not verified))
);
create index if not exists payments_order_idx on public.payments (order_id);
-- The same manual reference (for example a MoMo transaction ID) cannot be recorded twice.
create unique index if not exists payments_manual_ref_uq on public.payments (method, reference)
  where kind = 'manual' and reference is not null and reference <> '';

create table if not exists public.refunds (
  id bigint generated always as identity primary key,
  order_id uuid not null references public.orders (id),
  order_ref text not null,
  payment_id bigint references public.payments (id),
  amount numeric(12,2) not null check (amount > 0),
  method text not null check (method in ('cash', 'mtn_momo', 'telecel_cash', 'airteltigo_money', 'bank_transfer', 'card_manual', 'other')),
  reference text,
  reason text,
  recorded_by uuid,
  created_at timestamptz not null default now()
);

create table if not exists public.receipts (
  id uuid primary key default gen_random_uuid(),
  receipt_no text not null unique,
  order_id uuid not null references public.orders (id),
  kind text not null check (kind in ('sale', 'payment', 'refund')),
  data jsonb not null,
  issued_by uuid,
  issued_at timestamptz not null default now()
);

create table if not exists public.stock_movements (
  id bigint generated always as identity primary key,
  product_id text not null references public.products (id),
  qty_change int not null,
  reason text not null check (reason in ('initial', 'restock', 'sale', 'order', 'cancel_restore', 'return', 'damaged', 'adjustment')),
  order_id uuid references public.orders (id),
  note text,
  balance_after int not null,
  created_by uuid,
  created_at timestamptz not null default now()
);
create index if not exists stock_mv_product_idx on public.stock_movements (product_id, created_at desc);

create table if not exists public.returns (
  id bigint generated always as identity primary key,
  order_id uuid not null references public.orders (id),
  order_item_id bigint not null references public.order_items (id),
  product_id text not null,
  qty int not null check (qty > 0),
  condition text not null check (condition in ('restock', 'damaged')),
  note text,
  created_by uuid,
  created_at timestamptz not null default now()
);

create table if not exists public.expenses (
  id bigint generated always as identity primary key,
  expense_date date not null default current_date,
  category text not null,
  description text,
  amount numeric(12,2) not null check (amount > 0),
  method text,
  reference text,
  voided boolean not null default false,
  void_reason text,
  created_by uuid,
  created_at timestamptz not null default now()
);

create table if not exists public.audit_log (
  id bigint generated always as identity primary key,
  at timestamptz not null default now(),
  actor uuid,
  actor_email text,
  action text not null,
  ref text,
  meta jsonb not null default '{}'::jsonb
);

-- ------------------------------------------------------- default settings
insert into public.settings (key, value) values
 ('business', '{"name":"Pandox Decor & Furniture","owner":"Boateng Kwadwo Eric","address":"Akim Oda, Eastern Region, Ghana","phones":["0543900094","0538848601"],"email":"","tin":"","currency":"GHS","momo_number":"0543900094"}'),
 ('receipt',  '{"prefix":"PDX","pad":6,"footer":"Thank you for shopping with Pandox."}'),
 ('delivery', '{"flat_fee":0,"free_over":5000,"zones":[]}'),
 ('tax',      '{"enabled":false,"rate":15,"inclusive":true,"label":"VAT"}'),
 ('payment_methods', '["cash","mtn_momo","telecel_cash","airteltigo_money","bank_transfer","card_manual","other"]'),
 ('promo', '{"code":"PANDOX10","percent":10,"active":true,"ends_at":"2026-10-10T23:59:00+00:00"}'),
 ('sale',  '{"percent":15,"active":true,"ends_at":"2026-10-10T23:59:00+00:00"}')
on conflict (key) do nothing;

-- ------------------------------------------------------------ auth helpers
create or replace function public.is_staff() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.staff_members s where s.user_id = auth.uid() and s.active)
$$;
create or replace function public.is_owner() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.staff_members s where s.user_id = auth.uid() and s.active and s.role = 'owner')
$$;
create or replace function public.has_perm(p text) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.staff_members s
                  where s.user_id = auth.uid() and s.active and (s.role = 'owner' or p = any (s.permissions)))
$$;
create or replace function public.can_read(perms text[]) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.staff_members s
                  where s.user_id = auth.uid() and s.active and (s.role = 'owner' or s.permissions && perms))
$$;
create or replace function public.require_perm(p text) returns void language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm(p) then raise exception 'not allowed' using errcode = '42501'; end if;
end $$;
create or replace function public.whoami() returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object('user_id', s.user_id, 'email', s.email, 'name', s.display_name, 'role', s.role, 'permissions', s.permissions)
    from public.staff_members s where s.user_id = auth.uid() and s.active
$$;
create or replace function public.audit(p_action text, p_ref text, p_meta jsonb default '{}'::jsonb) returns void
language sql security definer set search_path = public as $$
  insert into public.audit_log (actor, actor_email, action, ref, meta)
  values (auth.uid(), (select email from public.staff_members where user_id = auth.uid()), p_action, p_ref, coalesce(p_meta, '{}'::jsonb))
$$;

create or replace function public.norm_phone(p text) returns text language sql immutable as $$
  select case
    when regexp_replace(coalesce(p, ''), '\D', '', 'g') ~ '^0\d{9}$'
      then '233' || substr(regexp_replace(p, '\D', '', 'g'), 2)
    else regexp_replace(coalesce(p, ''), '\D', '', 'g')
  end
$$;

-- ------------------------------------------------------------- protection
create or replace function public.block_change() returns trigger language plpgsql as $$
begin
  raise exception 'Financial, stock and audit records cannot be %d', lower(tg_op) using errcode = '42501';
end $$;

create or replace function public.payments_guard() returns trigger language plpgsql as $$
begin
  if (new.kind = 'provider' or new.verified) and coalesce(auth.role(), '') <> 'service_role' then
    raise exception 'Only the payment provider webhook can create verified payments' using errcode = '42501';
  end if;
  return new;
end $$;
drop trigger if exists payments_guard_trg on public.payments;
create trigger payments_guard_trg before insert on public.payments for each row execute function public.payments_guard();

create or replace function public.touch() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;
do $$
declare t text;
begin
  foreach t in array array['orders', 'products', 'customers'] loop
    execute format('drop trigger if exists touch_trg on public.%I', t);
    execute format('create trigger touch_trg before update on public.%I for each row execute function public.touch()', t);
  end loop;
  foreach t in array array['orders', 'order_items', 'payments', 'refunds', 'receipts', 'stock_movements', 'returns', 'expenses', 'audit_log', 'customers', 'products'] loop
    execute format('drop trigger if exists no_delete on public.%I', t);
    execute format('create trigger no_delete before delete on public.%I for each row execute function public.block_change()', t);
  end loop;
  foreach t in array array['payments', 'refunds', 'receipts', 'stock_movements', 'returns', 'audit_log'] loop
    execute format('drop trigger if exists no_update on public.%I', t);
    execute format('create trigger no_update before update on public.%I for each row execute function public.block_change()', t);
    execute format('drop trigger if exists no_truncate on public.%I', t);
    execute format('create trigger no_truncate before truncate on public.%I for each statement execute function public.block_change()', t);
  end loop;
end $$;

-- ---------------------------------------------------------- tax and totals
create or replace function public.tax_calc(p_base numeric) returns table (tax numeric, total numeric)
language plpgsql stable security definer set search_path = public as $$
declare v jsonb; v_rate numeric;
begin
  select value into v from public.settings where key = 'tax';
  if coalesce((v->>'enabled')::boolean, false) then
    v_rate := coalesce((v->>'rate')::numeric, 0) / 100;
    if coalesce((v->>'inclusive')::boolean, true) then
      return query select round(p_base - p_base / (1 + v_rate), 2), p_base;
    else
      return query select round(p_base * v_rate, 2), p_base + round(p_base * v_rate, 2);
    end if;
  else
    return query select 0::numeric, p_base;
  end if;
end $$;

create or replace function public.recalc_order(p_order uuid) returns void language plpgsql security definer set search_path = public as $$
declare v_paid numeric(12,2); v_ref numeric(12,2); v_total numeric(12,2); v_net numeric(12,2); v_ps text;
begin
  select coalesce(sum(amount), 0) into v_paid from public.payments where order_id = p_order;
  select coalesce(sum(amount), 0) into v_ref from public.refunds where order_id = p_order;
  select total into v_total from public.orders where id = p_order;
  v_net := v_paid - v_ref;
  v_ps := case when v_ref > 0 and v_net <= 0 then 'refunded'
               when v_total > 0 and v_net >= v_total then 'paid'
               when v_net > 0 then 'partial'
               else 'unpaid' end;
  update public.orders set amount_paid = v_paid, amount_refunded = v_ref, payment_status = v_ps where id = p_order;
end $$;

-- ------------------------------------------------------------------ stock
create or replace function public.stock_move(p_product text, p_delta int, p_reason text, p_order uuid, p_note text) returns int
language plpgsql security definer set search_path = public as $$
declare v_new int;
begin
  update public.products set stock = stock + p_delta where id = p_product returning stock into v_new;
  if v_new is null then raise exception 'unknown product %', p_product using errcode = '22023'; end if;
  insert into public.stock_movements (product_id, qty_change, reason, order_id, note, balance_after, created_by)
  values (p_product, p_delta, p_reason, p_order, p_note, v_new, auth.uid());
  return v_new;
end $$;

create or replace function public.adjust_stock(p_product text, p_delta int, p_reason text, p_note text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_prod public.products%rowtype; v_new int;
begin
  perform public.require_perm('inventory');
  if p_reason not in ('restock', 'damaged', 'adjustment', 'return') then raise exception 'invalid reason' using errcode = '22023'; end if;
  if p_delta = 0 then raise exception 'change must not be zero' using errcode = '22023'; end if;
  select * into v_prod from public.products where id = p_product for update;
  if not found then raise exception 'unknown product' using errcode = '22023'; end if;
  if v_prod.stock + p_delta < 0 then raise exception 'stock cannot go below zero' using errcode = '22023'; end if;
  v_new := public.stock_move(p_product, p_delta, p_reason, null, p_note);
  update public.products set track_stock = true where id = p_product and not track_stock;
  perform public.audit('stock_adjusted', p_product, jsonb_build_object('delta', p_delta, 'reason', p_reason, 'balance', v_new));
  return jsonb_build_object('product_id', p_product, 'stock', v_new);
end $$;

-- ---------------------------------------------------------------- receipts
create or replace function public.issue_receipt(p_order uuid, p_kind text, p_this jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare o public.orders%rowtype; rc jsonb; v_no text; v_id uuid; v_data jsonb;
begin
  select * into o from public.orders where id = p_order;
  select value into rc from public.settings where key = 'receipt';
  v_no := coalesce(rc->>'prefix', 'PDX') || '-' || to_char(now(), 'YYYY') || '-' ||
          lpad(nextval('public.receipt_seq')::text, coalesce((rc->>'pad')::int, 6), '0');
  v_data := jsonb_build_object(
    'receipt_no', v_no, 'kind', p_kind, 'issued_at', now(),
    'business', (select value from public.settings where key = 'business'),
    'footer', coalesce(rc->>'footer', ''),
    'tax_label', (select value->>'label' from public.settings where key = 'tax'),
    'order', jsonb_build_object('ref', o.ref, 'source', o.source, 'status', o.status, 'created_at', o.created_at),
    'customer', jsonb_build_object('name', o.customer_name, 'phone', o.phone, 'address', o.address),
    'items', coalesce((select jsonb_agg(jsonb_build_object('name', i.name, 'qty', i.qty, 'unit_price', i.unit_price, 'line_total', i.line_total) order by i.id)
                         from public.order_items i where i.order_id = o.id), '[]'::jsonb),
    'subtotal', o.subtotal, 'discount', o.discount, 'delivery_fee', o.delivery_fee, 'tax', o.tax_amount, 'total', o.total,
    'this', coalesce(p_this, '{}'::jsonb),
    'paid_to_date', o.amount_paid, 'refunded_to_date', o.amount_refunded,
    'balance', greatest(o.total - (o.amount_paid - o.amount_refunded), 0));
  insert into public.receipts (receipt_no, order_id, kind, data, issued_by)
  values (v_no, p_order, p_kind, v_data, auth.uid()) returning id into v_id;
  return v_id;
end $$;

-- ---------------------------------------------------------------- payments
create or replace function public.record_payment(p_order uuid, p_method text, p_amount numeric, p_reference text default null, p_note text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare o public.orders%rowtype; v_pid bigint; v_rid uuid; v_balance numeric(12,2);
begin
  perform public.require_perm('payments');
  select * into o from public.orders where id = p_order for update;
  if not found then raise exception 'order not found' using errcode = '22023'; end if;
  if o.status = 'cancelled' then raise exception 'order is cancelled' using errcode = '22023'; end if;
  if p_method not in ('cash', 'mtn_momo', 'telecel_cash', 'airteltigo_money', 'bank_transfer', 'card_manual', 'other') then
    raise exception 'invalid payment method' using errcode = '22023';
  end if;
  if p_amount is null or p_amount <= 0 then raise exception 'amount must be above zero' using errcode = '22023'; end if;
  v_balance := o.total - (o.amount_paid - o.amount_refunded);
  if p_amount > v_balance then raise exception 'amount is more than the balance of %', v_balance using errcode = '22023'; end if;
  insert into public.payments (order_id, order_ref, kind, verified, method, amount, reference, note, recorded_by)
  values (o.id, o.ref, 'manual', false, p_method, round(p_amount, 2), nullif(trim(coalesce(p_reference, '')), ''), p_note, auth.uid())
  returning id into v_pid;
  perform public.recalc_order(o.id);
  v_rid := public.issue_receipt(o.id, 'payment', jsonb_build_object('payments', jsonb_build_array(
             jsonb_build_object('method', p_method, 'amount', round(p_amount, 2), 'reference', p_reference, 'verification', 'recorded by staff, not provider verified'))));
  perform public.audit('payment_recorded', o.ref, jsonb_build_object('method', p_method, 'amount', p_amount, 'payment_id', v_pid));
  return jsonb_build_object('payment_id', v_pid, 'receipt_id', v_rid);
end $$;

create or replace function public.record_refund(p_order uuid, p_amount numeric, p_method text, p_reference text default null, p_reason text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare o public.orders%rowtype; v_rf bigint; v_rid uuid;
begin
  perform public.require_perm('refunds');
  select * into o from public.orders where id = p_order for update;
  if not found then raise exception 'order not found' using errcode = '22023'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'amount must be above zero' using errcode = '22023'; end if;
  if p_amount > o.amount_paid - o.amount_refunded then raise exception 'refund is more than the money received' using errcode = '22023'; end if;
  insert into public.refunds (order_id, order_ref, amount, method, reference, reason, recorded_by)
  values (o.id, o.ref, round(p_amount, 2), p_method, nullif(trim(coalesce(p_reference, '')), ''), p_reason, auth.uid())
  returning id into v_rf;
  perform public.recalc_order(o.id);
  v_rid := public.issue_receipt(o.id, 'refund', jsonb_build_object('refund', jsonb_build_object('method', p_method, 'amount', round(p_amount, 2), 'reference', p_reference, 'reason', p_reason)));
  perform public.audit('refund_recorded', o.ref, jsonb_build_object('method', p_method, 'amount', p_amount, 'refund_id', v_rf));
  return jsonb_build_object('refund_id', v_rf, 'receipt_id', v_rid);
end $$;

-- Provider-verified payments (Paystack webhook, service role only). Duplicate callbacks are ignored.
create or replace function public.mark_paid(p_ref text, p_provider_ref text, p_amount numeric, p_raw jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare o public.orders%rowtype; v_n int;
begin
  select * into o from public.orders where ref = p_ref for update;
  if not found then return jsonb_build_object('ok', false, 'reason', 'order not found'); end if;
  insert into public.payments (order_id, order_ref, kind, verified, method, amount, provider, provider_ref, raw)
  values (o.id, o.ref, 'provider', true, 'card_online', p_amount, 'paystack', p_provider_ref, p_raw)
  on conflict (provider_ref) do nothing;
  get diagnostics v_n = row_count;
  if v_n = 1 then
    perform public.recalc_order(o.id);
    perform public.issue_receipt(o.id, 'payment', jsonb_build_object('payments', jsonb_build_array(
      jsonb_build_object('method', 'card_online', 'amount', p_amount, 'reference', p_provider_ref, 'verification', 'verified by payment provider'))));
    perform public.audit('provider_payment', o.ref, jsonb_build_object('amount', p_amount, 'provider_ref', p_provider_ref));
  end if;
  return jsonb_build_object('ok', true, 'duplicate', v_n = 0);
end $$;

-- ------------------------------------------------------------------ orders
create or replace function public.create_order(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_ref text := p->>'ref'; v_phone text := public.norm_phone(p->>'phone');
  v_exist public.orders%rowtype; v_sale jsonb; v_promo jsonb; v_sale_on boolean := false;
  v_pct numeric := 0; v_subtotal numeric(12,2) := 0; v_discount numeric(12,2) := 0;
  v_order_id uuid; v_item jsonb; v_prod public.products%rowtype; v_qty int; v_unit numeric(12,2);
  v_cust uuid; v_tax numeric(12,2); v_total numeric(12,2);
begin
  select * into v_exist from public.orders where ref = v_ref;
  if found then
    return jsonb_build_object('ref', v_exist.ref, 'status', v_exist.status, 'total', v_exist.total, 'duplicate', true);
  end if;
  if v_ref !~ '^PX[A-Z0-9]{4,10}$' then raise exception 'invalid ref' using errcode = '22023'; end if;
  if jsonb_typeof(p->'items') <> 'array' or jsonb_array_length(p->'items') not between 1 and 30 then
    raise exception 'invalid items' using errcode = '22023';
  end if;
  if length(v_phone) < 11 or length(v_phone) > 15 then raise exception 'invalid phone' using errcode = '22023'; end if;
  if (select count(*) from public.orders where phone_norm = v_phone and created_at > now() - interval '1 hour') >= 10 then
    raise exception 'rate limit' using errcode = '54000';
  end if;

  select value into v_sale from public.settings where key = 'sale';
  v_sale_on := coalesce((v_sale->>'active')::boolean, false) and now() < (v_sale->>'ends_at')::timestamptz;

  insert into public.customers (name, phone, phone_norm, address, city, region)
  values (trim(p->>'name'), p->>'phone', v_phone, p->'address'->>'line', p->'address'->>'city', p->'address'->>'region')
  on conflict (phone_norm) do update
    set name = excluded.name, address = excluded.address, city = excluded.city, region = excluded.region
  returning id into v_cust;

  insert into public.orders (ref, source, customer_id, customer_name, phone, phone_norm, address, instructions, pay_method)
  values (v_ref, 'online', v_cust, trim(p->>'name'), p->>'phone', v_phone, coalesce(p->'address', '{}'::jsonb),
          nullif(trim(coalesce(p->>'instructions', '')), ''), p->>'payMethod')
  returning id into v_order_id;

  for v_item in select * from jsonb_array_elements(p->'items') loop
    v_qty := (v_item->>'qty')::int;
    if v_qty < 1 or v_qty > 99 then raise exception 'invalid quantity' using errcode = '22023'; end if;
    select * into v_prod from public.products
     where id = v_item->>'id' and is_active and published and min_price > 0 for update;
    if not found then raise exception 'unknown product %', v_item->>'id' using errcode = '22023'; end if;
    if v_prod.track_stock and v_prod.stock < v_qty then
      raise exception 'out of stock: %', v_prod.name using errcode = '22023';
    end if;
    v_unit := case when v_prod.on_sale and v_sale_on
                   then round(v_prod.min_price * (100 - (v_sale->>'percent')::numeric) / 100)
                   else v_prod.min_price end;
    insert into public.order_items (order_id, product_id, name, qty, unit_price, unit_cost, line_total)
    values (v_order_id, v_prod.id, v_prod.name, v_qty, v_unit, v_prod.cost_price, v_unit * v_qty);
    if v_prod.track_stock then
      perform public.stock_move(v_prod.id, -v_qty, 'order', v_order_id, null);
    end if;
    v_subtotal := v_subtotal + v_unit * v_qty;
  end loop;

  select value into v_promo from public.settings where key = 'promo';
  if coalesce(p->>'promo', '') <> ''
     and upper(p->>'promo') = upper(coalesce(v_promo->>'code', ''))
     and coalesce((v_promo->>'active')::boolean, false)
     and now() < (v_promo->>'ends_at')::timestamptz then
    v_pct := (v_promo->>'percent')::numeric;
  end if;
  v_discount := round(v_subtotal * v_pct / 100);
  select t.tax, t.total into v_tax, v_total from public.tax_calc(v_subtotal - v_discount) t;

  update public.orders
     set subtotal = v_subtotal, discount = v_discount, tax_amount = v_tax, total = v_total,
         promo = case when v_pct > 0 then upper(p->>'promo') else null end
   where id = v_order_id;

  perform public.audit('order_created', v_ref, jsonb_build_object('total', v_total, 'source', 'online'));
  return jsonb_build_object('ref', v_ref, 'status', 'pending', 'total', v_total);
end $$;

create or replace function public.track_order(p_ref text, p_phone text) returns jsonb
language sql security definer set search_path = public stable as $$
  select coalesce(
    (select jsonb_build_object('status', status, 'payment_status', payment_status, 'updated_at', updated_at)
       from public.orders where ref = p_ref and phone_norm = public.norm_phone(p_phone) limit 1),
    jsonb_build_object('status', 'not_found'))
$$;

create or replace function public.set_order_status(p_order uuid, p_status text, p_reason text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare o public.orders%rowtype; v_item record;
begin
  perform public.require_perm('orders');
  if p_status not in ('pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'cancelled') then
    raise exception 'invalid status' using errcode = '22023';
  end if;
  select * into o from public.orders where id = p_order for update;
  if not found then raise exception 'order not found' using errcode = '22023'; end if;
  if o.status in ('cancelled', 'returned') then raise exception 'order is already %', o.status using errcode = '22023'; end if;
  if p_status = 'cancelled' then
    for v_item in select i.product_id, i.qty - i.returned_qty as qty, pr.track_stock
                    from public.order_items i join public.products pr on pr.id = i.product_id where i.order_id = o.id loop
      if v_item.track_stock and v_item.qty > 0 then
        perform public.stock_move(v_item.product_id, v_item.qty, 'cancel_restore', o.id, 'order cancelled');
      end if;
    end loop;
    update public.orders set status = 'cancelled', cancelled_reason = p_reason where id = o.id;
  else
    update public.orders set status = p_status where id = o.id;
  end if;
  perform public.audit('order_status', o.ref, jsonb_build_object('from', o.status, 'to', p_status, 'reason', p_reason));
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.set_order_fees(p_order uuid, p_delivery_fee numeric, p_notes text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare o public.orders%rowtype; v_tax numeric(12,2); v_total numeric(12,2);
begin
  perform public.require_perm('orders');
  if p_delivery_fee < 0 then raise exception 'fee cannot be negative' using errcode = '22023'; end if;
  select * into o from public.orders where id = p_order for update;
  if not found then raise exception 'order not found' using errcode = '22023'; end if;
  select t.tax, t.total into v_tax, v_total from public.tax_calc(o.subtotal - o.discount) t;
  update public.orders set delivery_fee = round(p_delivery_fee, 2), tax_amount = v_tax,
         total = v_total + round(p_delivery_fee, 2), notes = coalesce(p_notes, notes) where id = o.id;
  perform public.recalc_order(o.id);
  perform public.audit('order_fee_set', o.ref, jsonb_build_object('delivery_fee', p_delivery_fee));
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.process_return(p_order uuid, p_item bigint, p_qty int, p_condition text, p_note text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare o public.orders%rowtype; it public.order_items%rowtype; v_track boolean; v_open int;
begin
  perform public.require_perm('orders');
  if p_condition not in ('restock', 'damaged') then raise exception 'invalid condition' using errcode = '22023'; end if;
  select * into o from public.orders where id = p_order for update;
  select * into it from public.order_items where id = p_item and order_id = p_order for update;
  if not found then raise exception 'item not found' using errcode = '22023'; end if;
  if p_qty < 1 or p_qty > it.qty - it.returned_qty then raise exception 'return quantity is too high' using errcode = '22023'; end if;
  update public.order_items set returned_qty = returned_qty + p_qty where id = it.id;
  insert into public.returns (order_id, order_item_id, product_id, qty, condition, note, created_by)
  values (o.id, it.id, it.product_id, p_qty, p_condition, p_note, auth.uid());
  select track_stock into v_track from public.products where id = it.product_id;
  if p_condition = 'restock' and v_track then
    perform public.stock_move(it.product_id, p_qty, 'return', o.id, p_note);
  elsif p_condition = 'damaged' and v_track then
    insert into public.stock_movements (product_id, qty_change, reason, order_id, note, balance_after, created_by)
    select it.product_id, 0, 'damaged', o.id, coalesce(p_note, 'returned damaged'), stock, auth.uid() from public.products where id = it.product_id;
  end if;
  select coalesce(sum(qty - returned_qty), 0) into v_open from public.order_items where order_id = o.id;
  if v_open = 0 then update public.orders set status = 'returned' where id = o.id; end if;
  perform public.audit('return_processed', o.ref, jsonb_build_object('item', p_item, 'qty', p_qty, 'condition', p_condition));
  return jsonb_build_object('ok', true);
end $$;

-- ------------------------------------------------------------ walk-in sales
create or replace function public.pos_sale(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_source text := coalesce(p->>'source', 'walk_in');
  v_ref text; v_phone text := public.norm_phone(p->'customer'->>'phone');
  v_cust uuid; v_name text := coalesce(nullif(trim(p->'customer'->>'name'), ''), 'Walk-in customer');
  v_order_id uuid; v_item jsonb; v_prod public.products%rowtype; v_qty int; v_unit numeric(12,2);
  v_subtotal numeric(12,2) := 0; v_discount numeric(12,2) := coalesce((p->>'discount')::numeric, 0);
  v_fee numeric(12,2) := coalesce((p->>'delivery_fee')::numeric, 0);
  v_tax numeric(12,2); v_total numeric(12,2); v_pay jsonb; v_paid numeric(12,2) := 0; v_amt numeric(12,2);
  v_rid uuid; v_pays jsonb := '[]'::jsonb;
begin
  perform public.require_perm('pos');
  if v_source not in ('walk_in', 'whatsapp') then raise exception 'invalid source' using errcode = '22023'; end if;
  if jsonb_typeof(p->'items') <> 'array' or jsonb_array_length(p->'items') not between 1 and 50 then
    raise exception 'add at least one item' using errcode = '22023';
  end if;
  if v_discount < 0 or v_fee < 0 then raise exception 'discount and fee cannot be negative' using errcode = '22023'; end if;
  v_ref := case when v_source = 'walk_in' then 'PW' else 'PQ' end || lpad(nextval('public.order_seq')::text, 6, '0');

  if length(v_phone) >= 11 then
    insert into public.customers (name, phone, phone_norm, address, city)
    values (v_name, p->'customer'->>'phone', v_phone, p->'customer'->>'address', p->'customer'->>'city')
    on conflict (phone_norm) do update set name = excluded.name,
      address = coalesce(excluded.address, public.customers.address), city = coalesce(excluded.city, public.customers.city)
    returning id into v_cust;
  else
    v_phone := '';
  end if;

  insert into public.orders (ref, source, customer_id, customer_name, phone, phone_norm, address, notes, status, created_by)
  values (v_ref, v_source, v_cust, v_name, coalesce(p->'customer'->>'phone', ''), v_phone,
          jsonb_build_object('line', p->'customer'->>'address', 'city', p->'customer'->>'city'),
          p->>'notes', case when v_source = 'walk_in' then 'delivered' else 'confirmed' end, auth.uid())
  returning id into v_order_id;

  for v_item in select * from jsonb_array_elements(p->'items') loop
    v_qty := (v_item->>'qty')::int;
    if v_qty < 1 or v_qty > 999 then raise exception 'invalid quantity' using errcode = '22023'; end if;
    select * into v_prod from public.products where id = v_item->>'id' and is_active for update;
    if not found then raise exception 'unknown product %', v_item->>'id' using errcode = '22023'; end if;
    if v_prod.track_stock and v_prod.stock < v_qty then raise exception 'out of stock: %', v_prod.name using errcode = '22023'; end if;
    v_unit := coalesce((v_item->>'unit_price')::numeric, v_prod.min_price);
    if v_unit < 0 then raise exception 'invalid price' using errcode = '22023'; end if;
    insert into public.order_items (order_id, product_id, name, qty, unit_price, unit_cost, line_total)
    values (v_order_id, v_prod.id, v_prod.name, v_qty, v_unit, v_prod.cost_price, v_unit * v_qty);
    if v_prod.track_stock then perform public.stock_move(v_prod.id, -v_qty, 'sale', v_order_id, v_ref); end if;
    v_subtotal := v_subtotal + v_unit * v_qty;
    if v_unit <> v_prod.min_price then
      perform public.audit('price_override', v_ref, jsonb_build_object('product', v_prod.id, 'list', v_prod.min_price, 'sold', v_unit));
    end if;
  end loop;

  if v_discount > v_subtotal then raise exception 'discount is more than the subtotal' using errcode = '22023'; end if;
  select t.tax, t.total into v_tax, v_total from public.tax_calc(v_subtotal - v_discount) t;
  v_total := v_total + v_fee;
  update public.orders set subtotal = v_subtotal, discount = v_discount, delivery_fee = v_fee, tax_amount = v_tax, total = v_total
   where id = v_order_id;

  for v_pay in select * from jsonb_array_elements(coalesce(p->'payments', '[]'::jsonb)) loop
    v_amt := (v_pay->>'amount')::numeric;
    if v_amt is null or v_amt <= 0 then continue; end if;
    if v_pay->>'method' not in ('cash', 'mtn_momo', 'telecel_cash', 'airteltigo_money', 'bank_transfer', 'card_manual', 'other') then
      raise exception 'invalid payment method' using errcode = '22023';
    end if;
    v_paid := v_paid + v_amt;
    if v_paid > v_total then raise exception 'payments are more than the total' using errcode = '22023'; end if;
    insert into public.payments (order_id, order_ref, kind, verified, method, amount, reference, recorded_by)
    values (v_order_id, v_ref, 'manual', false, v_pay->>'method', round(v_amt, 2), nullif(trim(coalesce(v_pay->>'reference', '')), ''), auth.uid());
    v_pays := v_pays || jsonb_build_array(jsonb_build_object('method', v_pay->>'method', 'amount', round(v_amt, 2),
                'reference', v_pay->>'reference', 'verification', 'recorded by staff, not provider verified'));
  end loop;
  perform public.recalc_order(v_order_id);
  v_rid := public.issue_receipt(v_order_id, 'sale', jsonb_build_object('payments', v_pays));
  perform public.audit('pos_sale', v_ref, jsonb_build_object('total', v_total, 'paid', v_paid, 'source', v_source));
  return jsonb_build_object('order_id', v_order_id, 'ref', v_ref, 'receipt_id', v_rid);
end $$;

-- ------------------------------------------------------------ catalogue admin
create or replace function public.save_category(p_name text, p_section text, p_sort int, p_active boolean, p_old text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  perform public.require_perm('products');
  if coalesce(trim(p_name), '') = '' then raise exception 'name is required' using errcode = '22023'; end if;
  if p_section not in ('market', 'decor') then raise exception 'invalid section' using errcode = '22023'; end if;
  if p_old is not null and p_old <> p_name then
    insert into public.categories (name, section, sort, is_active) values (trim(p_name), p_section, coalesce(p_sort, 0), coalesce(p_active, true))
    on conflict (name) do nothing;
    update public.products set category = trim(p_name) where category = p_old;
    update public.categories set is_active = false where name = p_old;
  else
    insert into public.categories (name, section, sort, is_active) values (trim(p_name), p_section, coalesce(p_sort, 0), coalesce(p_active, true))
    on conflict (name) do update set section = excluded.section, sort = excluded.sort, is_active = excluded.is_active;
  end if;
  perform public.audit('category_saved', p_name, jsonb_build_object('old', p_old));
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.save_product(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_id text := nullif(p->>'id', ''); v_new boolean := false; v_stock int := coalesce((p->>'stock')::int, 0);
begin
  perform public.require_perm('products');
  if coalesce(trim(p->>'name'), '') = '' or coalesce(trim(p->>'category'), '') = '' then
    raise exception 'name and category are required' using errcode = '22023';
  end if;
  if v_stock < 0 then raise exception 'stock cannot be negative' using errcode = '22023'; end if;
  insert into public.categories (name, section) values (trim(p->>'category'), coalesce(p->>'section', 'market')) on conflict (name) do nothing;
  if v_id is null then
    v_new := true;
    v_id := 'x' || lpad(nextval('public.product_seq')::text, 5, '0');
    insert into public.products (id, name, category, section, sub_category, description, image_url, min_price, max_price, cost_price,
                                 on_sale, stock, track_stock, low_stock_level, published, is_active)
    values (v_id, trim(p->>'name'), trim(p->>'category'), coalesce(p->>'section', 'market'), p->>'sub_category', p->>'description',
            nullif(p->>'image_url', ''), coalesce((p->>'min_price')::numeric, 0), nullif(p->>'max_price', '')::numeric,
            coalesce((p->>'cost_price')::numeric, 0), coalesce((p->>'on_sale')::boolean, false), v_stock,
            coalesce((p->>'track_stock')::boolean, false), coalesce((p->>'low_stock_level')::int, 3),
            coalesce((p->>'published')::boolean, true), coalesce((p->>'is_active')::boolean, true));
    if v_stock > 0 then
      insert into public.stock_movements (product_id, qty_change, reason, note, balance_after, created_by)
      values (v_id, v_stock, 'initial', 'opening stock', v_stock, auth.uid());
    end if;
  else
    update public.products set
      name = trim(p->>'name'), category = trim(p->>'category'), section = coalesce(p->>'section', section),
      sub_category = p->>'sub_category', description = p->>'description', image_url = nullif(p->>'image_url', ''),
      min_price = coalesce((p->>'min_price')::numeric, min_price), max_price = nullif(p->>'max_price', '')::numeric,
      cost_price = coalesce((p->>'cost_price')::numeric, cost_price), on_sale = coalesce((p->>'on_sale')::boolean, on_sale),
      track_stock = coalesce((p->>'track_stock')::boolean, track_stock), low_stock_level = coalesce((p->>'low_stock_level')::int, low_stock_level),
      published = coalesce((p->>'published')::boolean, published), is_active = coalesce((p->>'is_active')::boolean, is_active)
    where id = v_id;
    if not found then raise exception 'unknown product' using errcode = '22023'; end if;
  end if;
  perform public.audit(case when v_new then 'product_created' else 'product_updated' end, v_id, jsonb_build_object('name', p->>'name'));
  return jsonb_build_object('id', v_id);
end $$;

-- ------------------------------------------------------------ customers, expenses
create or replace function public.save_customer(p_id uuid, p_name text, p_address text, p_city text, p_notes text) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  perform public.require_perm('customers');
  update public.customers set name = coalesce(nullif(trim(p_name), ''), name), address = p_address, city = p_city, notes = p_notes where id = p_id;
  perform public.audit('customer_updated', p_id::text, '{}'::jsonb);
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.add_expense(p_date date, p_category text, p_description text, p_amount numeric, p_method text default null, p_reference text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_id bigint;
begin
  perform public.require_perm('expenses');
  if p_amount is null or p_amount <= 0 then raise exception 'amount must be above zero' using errcode = '22023'; end if;
  insert into public.expenses (expense_date, category, description, amount, method, reference, created_by)
  values (coalesce(p_date, current_date), coalesce(nullif(trim(p_category), ''), 'General'), p_description, round(p_amount, 2), p_method, p_reference, auth.uid())
  returning id into v_id;
  perform public.audit('expense_added', v_id::text, jsonb_build_object('amount', p_amount, 'category', p_category));
  return jsonb_build_object('id', v_id);
end $$;

create or replace function public.void_expense(p_id bigint, p_reason text) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  perform public.require_perm('expenses');
  update public.expenses set voided = true, void_reason = p_reason where id = p_id and not voided;
  perform public.audit('expense_voided', p_id::text, jsonb_build_object('reason', p_reason));
  return jsonb_build_object('ok', true);
end $$;

-- ------------------------------------------------------------------ settings
create or replace function public.save_settings(p_key text, p_value jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  perform public.require_perm('settings');
  if p_key not in ('business', 'receipt', 'delivery', 'tax', 'payment_methods', 'promo', 'sale') then
    raise exception 'unknown setting' using errcode = '22023';
  end if;
  insert into public.settings (key, value, updated_at) values (p_key, p_value, now())
  on conflict (key) do update set value = excluded.value, updated_at = now();
  perform public.audit('settings_saved', p_key, '{}'::jsonb);
  return jsonb_build_object('ok', true);
end $$;

-- --------------------------------------------------------------- staff (owner)
create or replace function public.set_staff(p_user uuid, p_email text, p_name text, p_perms text[], p_active boolean) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_allowed text[] := array['products', 'orders', 'payments', 'refunds', 'pos', 'inventory', 'customers', 'reports', 'expenses', 'settings'];
begin
  if not public.is_owner() then raise exception 'only the owner can manage staff' using errcode = '42501'; end if;
  if exists (select 1 from public.staff_members where user_id = p_user and role = 'owner') then
    raise exception 'the owner account cannot be changed here' using errcode = '42501';
  end if;
  if not (coalesce(p_perms, '{}') <@ v_allowed) then raise exception 'unknown permission' using errcode = '22023'; end if;
  insert into public.staff_members (user_id, email, display_name, role, permissions, active)
  values (p_user, p_email, p_name, 'staff', coalesce(p_perms, '{}'), coalesce(p_active, true))
  on conflict (user_id) do update set email = excluded.email, display_name = excluded.display_name,
    permissions = excluded.permissions, active = excluded.active;
  perform public.audit('staff_saved', p_user::text, jsonb_build_object('permissions', p_perms, 'active', p_active));
  return jsonb_build_object('ok', true);
end $$;

-- ------------------------------------------------------------ read helpers
create or replace function public.search_orders(p_q text default null, p_status text default null, p_limit int default 50) returns setof public.orders
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.can_read(array['orders', 'payments', 'pos']) then raise exception 'not allowed' using errcode = '42501'; end if;
  return query select * from public.orders o
    where (p_status is null or p_status = '' or o.status = p_status)
      and (p_q is null or p_q = '' or o.ref ilike '%' || p_q || '%' or o.customer_name ilike '%' || p_q || '%' or o.phone ilike '%' || p_q || '%')
    order by o.created_at desc limit least(greatest(coalesce(p_limit, 50), 1), 200);
end $$;

create or replace function public.order_detail(p_order uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.can_read(array['orders', 'payments', 'pos']) then raise exception 'not allowed' using errcode = '42501'; end if;
  return (select jsonb_build_object(
    'order', to_jsonb(o),
    'items', coalesce((select jsonb_agg(to_jsonb(i) order by i.id) from public.order_items i where i.order_id = o.id), '[]'::jsonb),
    'payments', coalesce((select jsonb_agg(to_jsonb(x) - 'raw' order by x.id) from public.payments x where x.order_id = o.id), '[]'::jsonb),
    'refunds', coalesce((select jsonb_agg(to_jsonb(r) order by r.id) from public.refunds r where r.order_id = o.id), '[]'::jsonb),
    'receipts', coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'receipt_no', c.receipt_no, 'kind', c.kind, 'issued_at', c.issued_at, 'data', c.data) order by c.issued_at) from public.receipts c where c.order_id = o.id), '[]'::jsonb))
    from public.orders o where o.id = p_order);
end $$;

create or replace function public.dashboard_summary() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_staff() then raise exception 'not allowed' using errcode = '42501'; end if;
  return jsonb_build_object(
    'today_sales', coalesce((select sum(total) from public.orders where created_at::date = current_date and status <> 'cancelled'), 0),
    'today_orders', (select count(*) from public.orders where created_at::date = current_date and status <> 'cancelled'),
    'today_received', coalesce((select sum(amount) from public.payments where received_at::date = current_date), 0)
                    - coalesce((select sum(amount) from public.refunds where created_at::date = current_date), 0),
    'open_orders', (select count(*) from public.orders where status in ('pending', 'confirmed', 'preparing', 'out_for_delivery')),
    'outstanding', coalesce((select sum(total - (amount_paid - amount_refunded)) from public.orders
                              where status not in ('cancelled', 'returned') and total - (amount_paid - amount_refunded) > 0), 0),
    'low_stock', (select count(*) from public.products where is_active and track_stock and stock <= low_stock_level));
end $$;

create or replace function public.report_summary(p_from date, p_to date, p_group text default 'day') returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare v jsonb;
begin
  perform public.require_perm('reports');
  if p_group not in ('day', 'week', 'month', 'year') then raise exception 'invalid grouping' using errcode = '22023'; end if;
  with
  o as (select date_trunc(p_group, created_at)::date as d, count(*) as orders, sum(total) as total, sum(total - tax_amount) as revenue, sum(discount) as discount
          from public.orders where status not in ('cancelled') and created_at::date between p_from and p_to group by 1),
  c as (select date_trunc(p_group, od.created_at)::date as d, sum(i.unit_cost * (i.qty - i.returned_qty)) as cogs
          from public.order_items i join public.orders od on od.id = i.order_id
         where od.status not in ('cancelled') and od.created_at::date between p_from and p_to group by 1),
  pm as (select date_trunc(p_group, received_at)::date as d, sum(amount) as received from public.payments where received_at::date between p_from and p_to group by 1),
  rf as (select date_trunc(p_group, created_at)::date as d, sum(amount) as refunded from public.refunds where created_at::date between p_from and p_to group by 1),
  ex as (select date_trunc(p_group, expense_date::timestamp)::date as d, sum(amount) as expenses from public.expenses where not voided and expense_date between p_from and p_to group by 1),
  periods as (select d from o union select d from c union select d from pm union select d from rf union select d from ex),
  series as (
    select p.d, coalesce(o.orders, 0) as orders, coalesce(o.total, 0) as sales, coalesce(o.revenue, 0) as revenue, coalesce(c.cogs, 0) as cogs,
           coalesce(pm.received, 0) as received, coalesce(rf.refunded, 0) as refunded, coalesce(ex.expenses, 0) as expenses,
           coalesce(o.revenue, 0) - coalesce(c.cogs, 0) - coalesce(ex.expenses, 0) as est_profit
      from periods p left join o on o.d = p.d left join c on c.d = p.d left join pm on pm.d = p.d left join rf on rf.d = p.d left join ex on ex.d = p.d)
  select jsonb_build_object(
    'series', coalesce((select jsonb_agg(to_jsonb(s) order by s.d) from series s), '[]'::jsonb),
    'totals', coalesce((select jsonb_build_object('orders', sum(orders), 'sales', sum(sales), 'revenue', sum(revenue), 'cogs', sum(cogs),
                'received', sum(received), 'refunded', sum(refunded), 'expenses', sum(expenses), 'est_profit', sum(est_profit)) from series), '{}'::jsonb),
    'by_method', coalesce((select jsonb_agg(jsonb_build_object('method', method, 'kind', kind, 'amount', amt))
                 from (select method, kind, sum(amount) as amt from public.payments where received_at::date between p_from and p_to group by 1, 2) m), '[]'::jsonb),
    'expenses_by_category', coalesce((select jsonb_agg(jsonb_build_object('category', category, 'amount', amt))
                 from (select category, sum(amount) as amt from public.expenses where not voided and expense_date between p_from and p_to group by 1) e), '[]'::jsonb),
    'outstanding', coalesce((select sum(total - (amount_paid - amount_refunded)) from public.orders
                  where status not in ('cancelled', 'returned') and total - (amount_paid - amount_refunded) > 0), 0))
  into v;
  return v;
end $$;

-- --------------------------------------------------------- public store view
create or replace view public.store_products as
  select id, name, category, section, sub_category, description, image_url, min_price, max_price, on_sale,
         case when track_stock then stock else null end as stock,
         (not track_stock or stock > 0) as in_stock
    from public.products where is_active and published;

-- ------------------------------------------------------------- RLS policies
alter table public.staff_members enable row level security;
alter table public.settings enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.customers enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payments enable row level security;
alter table public.refunds enable row level security;
alter table public.receipts enable row level security;
alter table public.stock_movements enable row level security;
alter table public.returns enable row level security;
alter table public.expenses enable row level security;
alter table public.audit_log enable row level security;

drop policy if exists staff_read on public.staff_members;
create policy staff_read on public.staff_members for select to authenticated using (user_id = auth.uid() or public.is_owner());
drop policy if exists settings_read on public.settings;
create policy settings_read on public.settings for select to authenticated using (public.is_staff());
drop policy if exists categories_read on public.categories;
create policy categories_read on public.categories for select to authenticated using (public.is_staff());
drop policy if exists products_read on public.products;
create policy products_read on public.products for select to authenticated using (public.can_read(array['products', 'pos', 'inventory', 'orders', 'reports']));
drop policy if exists customers_read on public.customers;
create policy customers_read on public.customers for select to authenticated using (public.can_read(array['customers', 'orders', 'pos']));
drop policy if exists orders_read on public.orders;
create policy orders_read on public.orders for select to authenticated using (public.can_read(array['orders', 'payments', 'pos', 'reports', 'customers']));
drop policy if exists order_items_read on public.order_items;
create policy order_items_read on public.order_items for select to authenticated using (public.can_read(array['orders', 'payments', 'pos', 'reports']));
drop policy if exists payments_read on public.payments;
create policy payments_read on public.payments for select to authenticated using (public.can_read(array['payments', 'refunds', 'orders', 'reports']));
drop policy if exists refunds_read on public.refunds;
create policy refunds_read on public.refunds for select to authenticated using (public.can_read(array['payments', 'refunds', 'orders', 'reports']));
drop policy if exists receipts_read on public.receipts;
create policy receipts_read on public.receipts for select to authenticated using (public.can_read(array['orders', 'payments', 'pos']));
drop policy if exists stock_read on public.stock_movements;
create policy stock_read on public.stock_movements for select to authenticated using (public.can_read(array['inventory', 'products', 'reports']));
drop policy if exists returns_read on public.returns;
create policy returns_read on public.returns for select to authenticated using (public.can_read(array['orders', 'inventory']));
drop policy if exists expenses_read on public.expenses;
create policy expenses_read on public.expenses for select to authenticated using (public.can_read(array['expenses', 'reports']));
drop policy if exists audit_read on public.audit_log;
create policy audit_read on public.audit_log for select to authenticated using (public.is_owner());
-- There are no insert, update or delete policies: every change goes through the functions above.

-- ----------------------------------------------------------- image storage
insert into storage.buckets (id, name, public) values ('product-images', 'product-images', true) on conflict (id) do nothing;
drop policy if exists "product images read" on storage.objects;
create policy "product images read" on storage.objects for select using (bucket_id = 'product-images');
drop policy if exists "product images write" on storage.objects;
create policy "product images write" on storage.objects for insert to authenticated with check (bucket_id = 'product-images' and public.has_perm('products'));
drop policy if exists "product images update" on storage.objects;
create policy "product images update" on storage.objects for update to authenticated using (bucket_id = 'product-images' and public.has_perm('products'));

-- ------------------------------------------------------------------ grants
revoke all on all tables in schema public from anon, authenticated;
grant select on all tables in schema public to authenticated;           -- rows are limited by the policies above
grant select on public.store_products to anon, authenticated;            -- customers see only safe columns, never costs
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.is_staff(), public.is_owner(), public.has_perm(text), public.can_read(text[]) to authenticated;
grant execute on function public.whoami(), public.adjust_stock(text, int, text, text), public.record_payment(uuid, text, numeric, text, text),
  public.record_refund(uuid, numeric, text, text, text), public.set_order_status(uuid, text, text), public.set_order_fees(uuid, numeric, text),
  public.process_return(uuid, bigint, int, text, text), public.pos_sale(jsonb), public.save_category(text, text, int, boolean, text),
  public.save_product(jsonb), public.save_customer(uuid, text, text, text, text), public.add_expense(date, text, text, numeric, text, text),
  public.void_expense(bigint, text), public.save_settings(text, jsonb), public.set_staff(uuid, text, text, text[], boolean),
  public.search_orders(text, text, int), public.order_detail(uuid), public.dashboard_summary(), public.report_summary(date, date, text) to authenticated;
grant execute on function public.create_order(jsonb), public.track_order(text, text), public.mark_paid(text, text, numeric, jsonb) to service_role;
grant all on all tables in schema public to service_role;
grant usage, select on all sequences in schema public to service_role, authenticated;
