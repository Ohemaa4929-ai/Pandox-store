# Pandox Owner Dashboard: setup

This creates the private dashboard at `admin.html`. Customers never see this page and cannot sign in to it; it is protected by a login and by database rules that reject every request from a non-staff account. Do this once.

## 1. Create the Supabase project
1. Go to supabase.com, create a free project. Pick a region close to Ghana (Europe, London is good).
2. Open the SQL editor. Open `schema.sql` from this folder, paste its full contents, and run it. It creates every table, locks them with row-level security, and creates the functions the dashboard uses. It is safe to run once on a fresh project.
3. Run `seed_products.sql`. It loads the 226 products already in your app, with their names, categories and prices, so the dashboard and the store start from the same list. It does nothing if a product id already exists, so it is safe to re-run.

## 2. Create your owner login
1. In Supabase, open Authentication, then Users, then Add user. Enter your email and a strong password. Untick "Auto confirm" only if you want an email confirmation step; for a first owner account, ticking it is simpler.
2. Copy the new user's ID (it looks like `8f1a2b3c-...`).
3. Back in the SQL editor, run this once, with your own ID and email:
   ```sql
   insert into public.staff_members (user_id, email, display_name, role, permissions, active)
   values ('PASTE-THE-USER-ID-HERE', 'owner@yourmail.com', 'Boateng Kwadwo Eric', 'owner', '{}', true);
   ```
   This is the only time you touch the database directly for staff. After this, you manage staff from the dashboard itself (More, Staff permissions), and the database stops anyone else from making themselves an owner.

## 3. Deploy the server functions
1. Install the Supabase CLI and sign in: `npm i -g supabase`, then `supabase login`.
2. From this `backend` folder: `supabase link --project-ref YOUR-PROJECT-REF`.
3. Deploy: `supabase functions deploy create-order` and `supabase functions deploy track-order`.
4. For card payments (optional): `supabase secrets set PAYSTACK_SECRET_KEY=sk_live_...`, then `supabase functions deploy paystack-webhook --no-verify-jwt`. In Paystack's dashboard, set the webhook URL to `https://YOUR-PROJECT-REF.supabase.co/functions/v1/paystack-webhook`, and when you create a payment link include `metadata.order_ref` set to the order's reference.

## 4. Connect the apps
Open `px-config.js` and fill in:
```js
api: {
  url: "https://YOUR-PROJECT-REF.supabase.co/functions/v1",
  projectUrl: "https://YOUR-PROJECT-REF.supabase.co",
  anonKey: "PASTE-THE-ANON-PUBLIC-KEY"   // Project Settings, API
}
```
Upload `px-config.js` to your site next to `index.html` and `admin.html`. The customer store (`index.html`) then reads live products, prices and stock from the database; it still falls back to its built-in list if it cannot reach the server. The dashboard (`admin.html`) needs this to work at all.

## 5. Open the dashboard
Go to `https://your-site.vercel.app/admin.html` on your phone. Sign in with the email and password from step 2. Add it to your home screen for one-tap access (Share, then Add to Home Screen). Nobody else can see this page unless you give them the link and a staff login (see below).

## Keeping customers out, and staff access
- The page itself has no public link anywhere in the customer app, and it is marked `noindex` so search engines will not list it.
- That alone is not real security, so every button also checks your login with the server: a customer who finds the URL sees a login form and nothing else, and every data request is rejected by the database unless it comes from a signed-in staff account with the right permission.
- To add a staff member: create their login the same way as step 2 (Authentication, Add user), but do not run the SQL insert. Instead, open the dashboard yourself, go to More, Staff permissions, Add staff member, paste their user ID, and tick only what they should be able to do. You can revoke access at any time from the same screen.

## Keeping the public store and the dashboard in sync
Both read from the same `products` table. When you add, edit or hide a product in the dashboard, the customer app picks it up the next time it has internet (it checks right away, and again if it has been open a while). Stock, sale status and prices are the same in both places, because they are the same database rows.
