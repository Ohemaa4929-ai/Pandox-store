# Backup and recovery

## Automatic backups
Supabase takes daily backups of your whole database on every paid plan, and keeps a short rolling backup on the free plan. In the Supabase dashboard: Project Settings, then Database, then Backups. For a live business, move to a paid plan so backups are kept longer and point-in-time recovery is available.

## Your own copy
Financial and order records in this app cannot be edited or deleted by anyone, even you, through the dashboard or the API (see `schema.sql`, the `no_delete` and `no_update` triggers). That protects you from accidental or malicious changes, but it is not a substitute for a backup: if the Supabase project itself were ever lost, so would these records be.

Take your own copies regularly:
- **Quick export:** in the dashboard, More, Export and backup, download the CSV files. Do this weekly and store the files somewhere other than this phone (email them to yourself, or save to Google Drive).
- **Full database dump:** `supabase db dump --file backup.sql` using the Supabase CLI, run monthly or before any major change. Keep a few dated copies.

## Restoring
1. For a single wrong entry: everything is additive (adjustments, refunds, returns), so correct it with a new adjustment, refund or return rather than editing history. The audit log (More, Audit log) shows exactly what happened and when.
2. For real data loss: use Supabase's point-in-time recovery from Project Settings, Database, Backups, or restore from your own `backup.sql` with `psql` or the Supabase CLI. Contact Supabase support for help with this; it is a database-level operation, not something the app does.
