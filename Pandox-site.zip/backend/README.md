# Pandox backend (Supabase)

Start with **ADMIN_SETUP.md** in this folder. It is the step-by-step guide to get the dashboard and the live store running. This file covers what each part does.

## What is here
- `schema.sql` — every table (products, orders, payments, customers, staff, and more), the rules that protect financial records from being edited or deleted, and about 35 functions that do all the real work (creating an order, recording a payment, adjusting stock, generating a receipt, building reports). Run this first.
- `seed_products.sql` — loads your 226 existing products into the database, generated from the app so nothing is retyped.
- `functions/create-order` — the customer app calls this to place an online order. It checks the request, then asks the database to price it (so the app can never fake a price).
- `functions/track-order` — the customer app calls this so a customer can see their order status, matched by order reference and phone number together.
- `functions/paystack-webhook` — if you turn on card payments, Paystack calls this. It checks Paystack's signature before trusting anything, so a payment cannot be faked by calling this URL directly.
- `ADMIN_SETUP.md` — how to create the project, your owner login, deploy the functions, and connect the apps.
- `BACKUP_RECOVERY.md` — how your data is protected and how to back it up yourself.

## How money and stock stay correct
- Every price for an online order comes from the `products` table on the server, never from the app. The app cannot send its own price.
- A payment is either `manual` (you recorded it after seeing cash or a MoMo message) or `provider` (Paystack told us it happened). Only the Paystack webhook, running with the service role key, can create a `provider` payment — the database rejects any attempt to create one from the dashboard or the public API, by a trigger (`payments_guard_trg` in `schema.sql`).
- The same Paystack event calling the webhook twice (which does happen) does not create a second payment, because `provider_ref` is unique and the function does nothing on a repeat.
- Stock only moves through `stock_move`, which also writes a row to `stock_movements`, so there is always a reason and a record for every change.
- Orders, payments, refunds, receipts, stock movements, returns and the audit log cannot be edited or deleted by anyone — not the owner, not staff, not through a bug in the dashboard — because the database itself refuses (`block_change()` triggers). Mistakes are fixed by adding a correcting entry, which is how real accounting works.

## Running the business day to day
- Change an order's status, record payments and refunds, add or edit products, and see reports — all from `admin.html`. You should rarely need the Supabase dashboard itself after setup.
- When the sale or the PANDOX10 code should end, update it in More, Business settings, in the dashboard — this is the same `settings` table both the store and the server check, so it ends in both places together.
- Look at More, Audit log for a plain record of who did what. Look at More, Export and backup to download your records.

## Known gaps
No push notifications, no barcode scanning, and the staff list is managed one person at a time (fine for a small team; would want a nicer screen past 5 to 10 staff). None of this blocks using the dashboard today.
