# Deploy the Pandox site

Upload everything in this folder to the root of your GitHub repository (branch main). Vercel then publishes it.

| File | What it is |
|---|---|
| `index.html` | The customer store |
| `admin.html` | The private owner dashboard. Not linked from anywhere public; reachable only if you know the address |
| `sw.js` | Lets the customer app open without internet after one visit |
| `manifest.json` and `icon-*.png` | Phone home-screen icon and install details |
| `px-config.js` | Your business details, policy numbers, payment link and backend address. Edit this one. Both `index.html` and `admin.html` read it |
| `legal.html` | Public page with all ten customer policies |
| `vercel.json` | Security headers, applied to every page including the dashboard |
| `backend/` | Database and server code for the dashboard. **Start with `backend/ADMIN_SETUP.md`** |
| `app-store/` | Files and a checklist for App Store and Play Store submission |

## First time here
1. Upload this folder's contents to GitHub so the customer store is live, as before.
2. Follow `backend/ADMIN_SETUP.md` from top to bottom to switch on the dashboard. Nothing here breaks the customer store if you skip this step — it keeps working from its built-in product list and WhatsApp checkout exactly as it did before.
3. Once `px-config.js` has your `api` details filled in, open `your-site.com/admin.html` on your phone and sign in.

After you upload: open the site on your phone once with internet, then switch on airplane mode and reopen it. The customer app should open and show the products you saw.
