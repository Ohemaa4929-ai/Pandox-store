# Pandox: App Store and Play Store checklist

No one can promise that Apple or Google will approve an app. This list covers what they check and shows where the Pandox app stands. Items marked **You** need something only you can supply.

## What a store needs that a web page cannot give
Apple accepts native apps, not web pages. The app files are wrapped with Capacitor so they install like any app. You need:
- **You:** an Apple Developer Program membership (paid yearly) and a Mac with Xcode to build and upload the iPhone app.
- **You:** a Google Play Console account to publish on Android. Android needs no Mac.

## Steps to build the app
1. Install Node.js. In a new folder run: `npm init -y`, then `npm i @capacitor/core @capacitor/cli @capacitor/ios @capacitor/android`.
2. Put `capacitor.config.json` in the folder. Copy `index.html`, `legal.html`, `manifest.json`, `px-config.js` and the icons into a folder named `www`. Do not copy `sw.js`. The app files are already inside the app, and the page skips the service worker when it runs inside the app.
3. Run `npx cap add ios` and `npx cap add android`, then `npx cap sync`.
4. iPhone: run `npx cap open ios`. In Xcode set your team and the bundle id (change `com.pandox.store` if you prefer), add `icon-1024.png` as the App Store icon, and add `PrivacyInfo.xcprivacy` to the app target.
5. In Xcode, set `ITSAppUsesNonExemptEncryption` to NO in Info.plist. The app only uses standard HTTPS.
6. Archive and upload to App Store Connect. Test with TestFlight before you submit.

## Apple review guidelines and the app today
| Guideline | What it asks | Status |
|---|---|---|
| 5.1.1 Privacy policy | A privacy policy link in the app and in App Store Connect | In app (Account, Legal and policies). Public page: `https://YOUR-SITE/legal.html#privacy`. **You:** paste that link into App Store Connect. |
| 5.1.1(v) Account deletion | If people can create an account, they can delete it in the app | Done: Account, My data and privacy, Delete my account and data. |
| 5.1.1 Data collection | Say what you collect, ask consent, collect only what you need | Done: name, phone, address and orders only. Consent tick at sign-up. No trackers. |
| 5.1.2 App Privacy answers | Fill in the privacy "nutrition label" | Use `PrivacyInfo.xcprivacy`. Answer: contact info, physical address and purchase history are collected for app functionality, linked to the user, not used for tracking. |
| 3.1.1 Payments | Digital goods use in-app purchase. Physical goods may use other payments | Furniture and decor are physical goods, so Mobile Money and card links are allowed. **Ebooks are digital:** Apple may require in-app purchase for them. The safest route is to remove ebook sales from the iPhone app, or sell them only on the website. |
| 4.2 Minimum functionality | The app must be more than a repackaged website | **Risk.** The app has accounts, wishlist, offline mode, orders and support. Apple still rejects some wrapped sites. Adding native features such as push notifications and share sheets through Capacitor plugins lowers the risk. |
| 2.1 App completeness | No placeholder content, no crashes, working links | Fill every item in `px-config.js` (business name, address, email) before you submit. Test every button on a real phone. |
| 5.2 Intellectual property | You must own or have rights to all content | **Risk.** Many product photos look like web or stock images and some carry another seller's watermark. Replace them with your own photos before you submit. |
| 1.5 Developer information | Working support contact | Add your support email in `px-config.js`. The support page is `https://YOUR-SITE/legal.html#contact`. |
| 4.8 Login services | Offer Sign in with Apple only if you offer other social logins | Not needed. The app has no social login. |

## Android (Google Play)
- Use the Play Console Data safety form with the same answers as above.
- Add the privacy policy link and the account deletion link (`https://YOUR-SITE/legal.html#privacy`).
- Build a signed bundle from `android/` in Android Studio and upload it.

## Security already in place
HTTPS only, security headers and a content security policy in `vercel.json`, no third-party scripts, no card data in the app, server-side pricing and rate limits once the backend is on, and escaped output for everything a user types.

## Before you submit
- [ ] Business details filled in `px-config.js`
- [ ] Own product photos in place
- [ ] Privacy policy link added in App Store Connect
- [ ] Ebooks decision made for iPhone
- [ ] Tested on a real iPhone and an Android phone, with and without internet
